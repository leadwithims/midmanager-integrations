import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logger = new Logger('Bootstrap');

  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  app.use((req, res, next) => {
    res.setHeader('x-tenant-id', 'default');
    next();
  });

  await app.listen(3005);
  logger.log(`🚀 Application is running on: http://localhost:3005`);
}

bootstrap();
