export class GithubMetricsDto {
  repositoryCount: number;
  repositoryList: string[];
  timestamp: Date;
}
