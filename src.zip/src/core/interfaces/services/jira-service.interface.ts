export interface IJiraService {
    getClient(): any;
    getBaseUrl(): string;
    getAuth(): string;
  }